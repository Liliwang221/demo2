import React from 'react'
const Classify:React.FC=()=>{
    return<div>
        分类
    </div>
}
export default Classify;