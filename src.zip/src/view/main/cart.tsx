import React from 'react'
const Cart:React.FC=()=>{
    return<div>
        购物车
    </div>
}
export default Cart;