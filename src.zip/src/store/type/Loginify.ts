export interface LoginList{
    mobile: string,
    password:string
}